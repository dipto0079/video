-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Mar 16, 2020 at 10:56 AM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `v120_test`
--

-- --------------------------------------------------------

--
-- Table structure for table `config`
--
UPDATE `config` SET `value` = '3.2.8' WHERE `config`.`title` = 'version';

DROP TABLE IF EXISTS `temp_config`;
CREATE TABLE IF NOT EXISTS `temp_config` (
  `config_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`config_id`)
) ENGINE=MyISAM AUTO_INCREMENT=262 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `config`
--

INSERT INTO `temp_config` (`config_id`, `title`, `value`) VALUES
(194, 'system_name', 'OVOO'),
(195, 'site_name', 'ovoo'),
(196, 'business_address', ''),
(197, 'business_phone', ''),
(NULL, 'admob_native_ads_id', 'xxxxxxxxxxx'),
(NULL, 'offline_payment_enable', 'false'),
(NULL, 'offline_payment_title', 'Offline Payment'),
(NULL, 'offline_payment_instruction', 'Offline payment instruction goes here.'),
(NULL, 'movie_page_slider', '1'),
(NULL, 'tv_series_page_slider', '1');

DROP TABLE IF EXISTS `homepage_sections`;
CREATE TABLE `homepage_sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `content_type` varchar(50) DEFAULT NULL,
  `layout` tinyint(4) DEFAULT NULL,
  `order` tinyint(4) DEFAULT '0',
  `genre_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci ;

--
-- Dumping data for table `homepage_sections`
--

INSERT INTO `homepage_sections` (`id`, `title`, `content_type`, `layout`, `order`, `genre_id`) VALUES
(NULL, 'Latest Episodes', 'latest_episodes', NULL, 10, NULL),
(NULL, 'Latest Movies', 'latest_movies', NULL, 4, NULL),
(NULL, 'Latest Series', 'latest_tvseries', NULL, 5, NULL),
(NULL, 'Popular Movies', 'popular_movies', NULL, 7, NULL),
(NULL, 'Popular Tv Series', 'popular_tv_series', NULL, 8, NULL),
(NULL, 'Live TV', 'live_tv_list', NULL, 1, NULL),
(NULL, 'Popular Actor', 'popular_actors', NULL, 2, NULL),
(NULL, 'Animation', 'genre', NULL, 3, 5);
ALTER TABLE `star` CHANGE `star_name` `star_name` VARCHAR(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
