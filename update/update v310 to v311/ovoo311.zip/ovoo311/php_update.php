<?php

    // $config_file_path   = "./../application/config/config.php";
    // $config_file        = file_get_contents($config_file_path);
    // $config_file        = preg_replace('/MY_/', 'Core_', $config_file, 1); //replace the first occurrence of 'MY_'
    // file_put_contents($config_file_path, $index_file);



	$CI = get_instance();
	$CI->load->database();
	$CI->load->dbforge();
	
	//update version
	$condition = array(
	    'title' => 'version'
	);
	if($CI->db->get_where('config', $condition)->num_rows() > 0):
		$data['value'] 	= 	'3.1.1';
		$CI->db->where($condition);
		$CI->db->update('config',$data);
	else:
		$data['title'] 	= 	'version';
		$data['value'] 	= 	'3.1.1';
		$CI->db->insert('config',$data);
	endif;

    //update app_menu
    $condition = array(
        'title' => 'app_menu'
    );
    if($CI->db->get_where('config', $condition)->num_rows() > 0):
        $data['value']  =   'grid';
        $CI->db->where($condition);
        $CI->db->update('config',$data);
    else:
        $data['title']  =   'app_menu';
        $data['value']  =   'grid';
        $CI->db->insert('config',$data);
    endif;

    //update app_program_guide_enable
    $condition = array(
        'title' => 'app_program_guide_enable'
    );
    if($CI->db->get_where('config', $condition)->num_rows() > 0):
        $data['value']  =   'false';
        $CI->db->where($condition);
        $CI->db->update('config',$data);
    else:
        $data['title']  =   'app_program_guide_enable';
        $data['value']  =   'false';
        $CI->db->insert('config',$data);
    endif;

    //update app_mandatory_login
    $condition = array(
        'title' => 'app_mandatory_login'
    );
    if($CI->db->get_where('config', $condition)->num_rows() > 0):
        $data['value']  =   'false';
        $CI->db->where($condition);
        $CI->db->update('config',$data);
    else:
        $data['title']  =   'app_mandatory_login';
        $data['value']  =   'false';
        $CI->db->insert('config',$data);
    endif;

    //update genre_visible
    $condition = array(
        'title' => 'genre_visible'
    );
    if($CI->db->get_where('config', $condition)->num_rows() > 0):
        $data['value']  =   'true';
        $CI->db->where($condition);
        $CI->db->update('config',$data);
    else:
        $data['title']  =   'genre_visible';
        $data['value']  =   'true';
        $CI->db->insert('config',$data);
    endif;

    //update country_visible
    $condition = array(
        'title' => 'country_visible'
    );
    if($CI->db->get_where('config', $condition)->num_rows() > 0):
        $data['value']  =   'true';
        $CI->db->where($condition);
        $CI->db->update('config',$data);
    else:
        $data['title']  =   'country_visible';
        $data['value']  =   'true';
        $CI->db->insert('config',$data);
    endif;

    //update movie_report_note
    $condition = array(
        'title' => 'movie_report_note'
    );
    if($CI->db->get_where('config', $condition)->num_rows() > 0):
        
    else:
        $data['title']  =   'movie_report_note';
        $data['value']  =   '';
        $CI->db->insert('config',$data);
    endif;


    // add last_ep_add column
    if (!$CI->db->field_exists('last_ep_added', 'videos')):
        $last_ep_added = array(
            'last_ep_added' => array(
                'type' => 'datetime',
                'default'=>'2019-01-01 00:00:00',
            ),
        );
        $CI->dbforge->add_column('videos', $last_ep_added);
    endif;

    // add last_ep_add column
    if (!$CI->db->field_exists('last_ep_added', 'episodes')):
        $last_ep_added2 = array(
            'last_ep_added' => array(
                'type' => 'datetime',
                'default'=>'2019-01-01 00:00:00',
            ),
        );
        $CI->dbforge->add_column('episodes', $last_ep_added2);
    endif;

    // add order column
    if (!$CI->db->field_exists('order', 'episodes')):
        $order = array(
            'order' => array(
                'type' => 'INT',
                'constraint' => 50,
                'default'=>'0',
            ),
        );
        $CI->dbforge->add_column('episodes', $order);
    endif;

    // add order column
    if (!$CI->db->field_exists('order', 'seasons')):
        $seasons = array(
            'order' => array(
                'type' => 'INT',
                'constraint' => 50,
                'default'=>'0',
            ),
        );
        $CI->dbforge->add_column('seasons', $seasons);
    endif;

    // add order column
    if (!$CI->db->field_exists('order', 'video_file')):
        $video_file = array(
            'order' => array(
                'type' => 'INT',
                'constraint' => 50,
                'default'=>'0',
            ),
        );
        $CI->dbforge->add_column('video_file', $video_file);
    endif;

    // add label column
    if (!$CI->db->field_exists('label', 'video_file')):
        $label2 = array(
            'label' => array(
                'type' => 'INT',
                'constraint' => 50,
                'default'=>'0',
            ),
        );
        $CI->dbforge->add_column('video_file', $label2);
    endif;

    // update tv category slug
    $tv_categories = $CI->db->get('live_tv_category')->result_array();
    foreach ($tv_categories as $row):
        $data_tv_category['slug']   = url_title($row['live_tv_category'], 'dash', TRUE);
        $CI->db->where('live_tv_category_id',$row['live_tv_category_id']);
        $CI->db->update('live_tv_category',$data_tv_category);
    endforeach;
    
?>
