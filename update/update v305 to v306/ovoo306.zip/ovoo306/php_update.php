<?php
	$CI = get_instance();
	$CI->load->database();
	$CI->load->dbforge();
	
	//update version
	$condition = array(
	    'title' => 'version'
	);
	if($CI->db->get_where('config', $condition)->num_rows() > 0):
		$data['value'] 	= 	'3.0.6';
		$CI->db->where($condition);
		$CI->db->update('config',$data);
	else:
		$data['title'] 	= 	'version';
		$data['value'] 	= 	'3.0.6';
		$CI->db->insert('config',$data);
	endif;

    //update app_menu
    $condition = array(
        'title' => 'app_menu'
    );
    if($CI->db->get_where('config', $condition)->num_rows() > 0):
        $data['value']  =   'grid';
        $CI->db->where($condition);
        $CI->db->update('config',$data);
    else:
        $data['title']  =   'app_menu';
        $data['value']  =   'grid';
        $CI->db->insert('config',$data);
    endif;

    //update app_program_guide_enable
    $condition = array(
        'title' => 'app_program_guide_enable'
    );
    if($CI->db->get_where('config', $condition)->num_rows() > 0):
        $data['value']  =   'false';
        $CI->db->where($condition);
        $CI->db->update('config',$data);
    else:
        $data['title']  =   'app_program_guide_enable';
        $data['value']  =   'false';
        $CI->db->insert('config',$data);
    endif;

    //update app_mandatory_login
    $condition = array(
        'title' => 'app_mandatory_login'
    );
    if($CI->db->get_where('config', $condition)->num_rows() > 0):
        $data['value']  =   'false';
        $CI->db->where($condition);
        $CI->db->update('config',$data);
    else:
        $data['title']  =   'app_mandatory_login';
        $data['value']  =   'false';
        $CI->db->insert('config',$data);
    endif;

    //update genre_visible
    $condition = array(
        'title' => 'genre_visible'
    );
    if($CI->db->get_where('config', $condition)->num_rows() > 0):
        $data['value']  =   'true';
        $CI->db->where($condition);
        $CI->db->update('config',$data);
    else:
        $data['title']  =   'genre_visible';
        $data['value']  =   'true';
        $CI->db->insert('config',$data);
    endif;

    //update country_visible
    $condition = array(
        'title' => 'country_visible'
    );
    if($CI->db->get_where('config', $condition)->num_rows() > 0):
        $data['value']  =   'true';
        $CI->db->where($condition);
        $CI->db->update('config',$data);
    else:
        $data['title']  =   'country_visible';
        $data['value']  =   'true';
        $CI->db->insert('config',$data);
    endif;


	// create program guide table
	$fields = array(
        'live_tv_program_guide_id' => array(
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => TRUE,
                'auto_increment' => TRUE
        ),
        'live_tv_id' => array(
                'type' => 'INT',
                'constraint' => 50,
                'null' => FALSE,
        ),
        'title' => array(
                'type' => 'VARCHAR',
                'constraint' => '250',
                'null' => FALSE,
        ),
        'video_url' => array(
                'type' => 'text',
                'null' => TRUE,
        ),
        'date' => array(
                'type' => 'date',
                'null' => FALSE,
        ),
        'time' => array(
                'type' => 'time',
                'null' => FALSE,
        ),
        'type' => array(
                'type' =>'ENUM("onaired","upcoming")',
                'null' => FALSE,
                'default' => 'upcoming',
        ),
        'status' => array(
                'type' => 'INT',
                'null' => FALSE,
                'default'=>'1',
        ),
	);	
	$CI->dbforge->add_field($fields);
	$CI->dbforge->add_key('live_tv_program_guide_id', TRUE);
	$CI->dbforge->create_table('live_tv_program_guide', TRUE);

	// modify download table
	$fields2 = array(
	        'resolution' => array(
	        	'type' => 'VARCHAR',
	        	'constraint' => 250,
	        	'null' => FALSE,
                'default'=>'720p',
            ),
            'file_size' => array(
	        	'type' => 'VARCHAR',
	        	'constraint' => 250,
	        	'null' => FALSE,
                'default'=>'00MB',
            ),
	);
	$CI->dbforge->add_column('download_link', $fields2);
?>
